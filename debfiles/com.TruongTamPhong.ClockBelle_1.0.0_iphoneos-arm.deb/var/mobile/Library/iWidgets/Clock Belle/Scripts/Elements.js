var clockElements, clockMethods, weatherElements, weatherMethods, systemElements, systemMethods;
clockElements = {
    'zhour': ['zhour'],
    'minute': ['minute'],
    'datesingled': ['date', '-', 'monthdate', '-', 'year'],



};
weatherElements = {
};
systemElements = {
};
clockMethods = {
  daysInMonth: [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31],
   hour: function() {
        var hour = (options.twentyfour === true) ? date.getHours() : (date.getHours() + 11) % 12 + 1;
        return hour;
    },
    zhour: function() {
        var hour = (options.twentyfour === true) ? date.getHours() : (date.getHours() + 11) % 12 + 1;
        hour = hour < 10 ? "0" + hour : " " + hour;
        return hour;
    },
   
   minute: function() {
        return (date.getMinutes() < 10) ? "0" + date.getMinutes() : date.getMinutes();
    },
   
   date: function() {
        return date.getDate();
    },
    paddeddate: function() {
        return (date.getDate() <= 9) ? "0" + date.getDate() : date.getDate();
    },
    paddeddatecut0: function() {
        return (date.getDate() <= 9) ? String("0" + date.getDate()).charAt(0) : String(date.getDate()).charAt(0);
    },
    paddeddatecut1: function() {
        return (date.getDate() <= 9) ? String("0" + date.getDate()).charAt(1) : String(date.getDate()).charAt(1);
    },
   
   prevdate: function() {
        var pd = (this.date() === 0) ? this.daysInMonth[this.month() - 1] : this.date() - 1;
        return pd;
    },
    nextdate: function() {
        var nd = (this.date() === 0) ? this.daysInMonth[this.month() + 1] : this.date() + 1;
        return nd;
    },
    day: function() {
        return date.getDay();
    },
    month: function() {
        return date.getMonth();
    },
    monthdate: function() {
        var month = date.getMonth() + 1;
        if (month > 12) {
            month = 0;
        }
        return month;
    },
    year: function() {
        return date.getFullYear();
    },
    yearslice24: function() {
        return date.getFullYear().toString().slice(2, 4);
    },
    smyear: function() {
        return date.getFullYear() % 1000;
    },
    daysLeft: function() {
        var nextYear = new Date("Jan 1, " + Number(date.getFullYear() + 1) + " 00:00:00").getTime(),
            today = new Date().getTime(),
            sep = nextYear - today,
            days = Math.floor(sep / (1000 * 60 * 60 * 24));
        //var hours = Math.floor((sep % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        //var minutes = Math.floor((sep % (1000 * 60 * 60)) / (1000 * 60));
        //var seconds = Math.floor((sep % (1000 * 60)) / 1000);
        return days;
    },
    hourtext: function() {
        var hourtxt;
        if (options.languages === 'fr') {
            hourtxt = (options.twentyfour === true) ? ["Minuit", "Une heure", "Deux heures", "Trois heures", "Quatre heures", "Cing heures", "Six heures", "Sept heures", "Huit heures", "Neuf heures", "Dix heures", "Onze heures", "Midi", "Treize heures", "Quatorze heures", "Quinze heures", "Seize heures", "Dix-sept heures", "Dix-huit heures", "Dix-neuf heures", "Vingt heures", "Vingt et une heures", "Vingt-deux heures", "Vingt-trois heures", "Minuit"] : ["Minuit", "Une heure", "Deux heure", "Trois heure", "Quatre heure", "Cing heure", "Six heure", "Sept heure", "Huit heure", "Neuf heure", "Dix heure", "Onze heure", "Midi", "Une heure", "Deux heure", "Trois heure", "Quatre heure", "Cing heure", "Six heure", "Sept heure", "Huit heure", "Neuf heure", "Dix heure", "Onze heure", "Minuit"];
        } else {
            hourtxt = (options.twentyfour === true) ? ["Twelve", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen", "Twenty", "Twenty One", "Twenty Two", "Twenty Three", "Twenty Four"] : ["Twelve", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve"];
        }
        return hourtxt[this.rawhour()];
    },
    hourtextdot: function() {
        var hourtxt = (options.twentyfour === true) ? ["Twelve", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen", "Twenty", "Twenty.One", "Twenty.Two", "Twenty.Three", "Twenty.Four"] : ["Twelve", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve"];
        return hourtxt[this.rawhour()];
    },
    minuteonetext: function() {
        var minuteone;
        if (options.languages === 'fr') {
            minuteone = ["", "et une", "et deux", "et trois", "et quatre", "et cinq", "et six", "et sept", "et huit", "et neuf", "et dix", "et onze", "et douze", "et treize", "et quatorze", "et quinze", "et seize", "et dix-sept", "et dix-huit", "et dix-neuf", "et vingt", "et vingt", "et vingt", "et vingt", "et vingt", "et vingt", "et vingt", "et vingt", "et vingt", "et vingt", "et trente", "et trente", "et trente", "et trente", "et trente", "et trente", "et trente", "et trente", "et trente", "et trente", "et quarante", "et quarante", "et quarante", "et quarante", "et quarante", "et quarante", "et quarante", "et quarante", "et quarante", "et quarante", "et cinquante", "et cinquante", "et cinquante", "et cinquante", "et cinquante", "et cinquante", "et cinquante", "et cinquante", "et cinquante", "et cinquante", "et cinquante"];
        } else {
            minuteone = ["o' clock", "o' one", "o' two", "o' three", "o' four", "o' five", "o' six", "o' seven", "o' eight", "o' nine", "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "Sixteen", "Seventeen", "eighteen", "Nineteen", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty"];
        }
        if (minuteone[this.rawminute()] !== undefined) {
            return minuteone[this.rawminute()];
        }
        return "";
    },
    minuteonetextdot: function() {
        var minuteone;
        if (options.languages === 'fr') {
            minuteone = ["", "et.une", "et.deux", "et.trois", "et.quatre", "et.cinq", "et.six", "et.sept", "et.huit", "et.neuf", "et.dix", "et.onze", "et.douze", "et.treize", "et.quatorze", "et.quinze", "et.seize", "et.dix-sept", "et.dix-huit", "et.dix-neuf", "et.vingt", "et.vingt", "et.vingt", "et.vingt", "et.vingt", "et.vingt", "et.vingt", "et.vingt", "et.vingt", "et.vingt", "et.trente", "et.trente", "et.trente", "et.trente", "et.trente", "et.trente", "et.trente", "et.trente", "et.trente", "et.trente", "et.quarante", "et.quarante", "et.quarante", "et.quarante", "et.quarante", "et.quarante", "et.quarante", "et.quarante", "et.quarante", "et.quarante", "et.cinquante", "et.cinquante", "et.cinquante", "et.cinquante", "et.cinquante", "et.cinquante", "et.cinquante", "et.cinquante", "et.cinquante", "et.cinquante", "et.cinquante"];
        } else {
            minuteone = ["", "one", "o.two", "o.three", "o.four", "o.five", "o.six", "o.seven", "o.eight", "o.nine", "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "Sixteen", "Seventeen", "eighteen", "Nineteen", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty"];
        }
        if (minuteone[this.rawminute()] !== undefined) {
            return minuteone[this.rawminute()];
        }
        return "";
    },
    minutetwotext: function() {
        var minutetwo;
        if (options.languages === 'fr') {
            minutetwo = ["", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "et-un", "deux", "trois", "quatre", "cinq", "six", "sept", "huit", "neuf", "", "et-un", "deux", "trois", "quatre", "cinq", "six", "sept", "huit", "neuf", "", "et-un", "deux", "trois", "quatre", "cinq", "six", "sept", "huit", "neuf", "", "et-un", "deux", "trois", "quatre", "cinq", "six", "sept", "huit", "neuf", ""];
        } else {
            minutetwo = ["", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", ""];
        }
        if (minutetwo[this.rawminute()] !== undefined) {
            return minutetwo[this.rawminute()];
        }
        return "";
    },
    daytext: function() {
        return translate[options.languages].weekday[this.day()];
    },
    daytextcut: function() {
        return translate[options.languages].weekday[this.day()].substring(3);
    },
    yesterdaydaytext: function() {
        return (this.day() === 0) ? translate[options.languages].weekday[6] : translate[options.languages].weekday[this.day() - 1];
    },
    nextdaytext: function() {
        return (this.day() === 6) ? translate[options.languages].weekday[0] : translate[options.languages].weekday[this.day() + 1];
    },
    sdaytext: function() {
        return translate[options.languages].sday[this.day()];
    },
    sdaytextslice01: function() {
        return String(translate[options.languages].sday[this.day()]).slice(0, 1);
    },
    sdaytextslice12: function() {
        return String(translate[options.languages].sday[this.day()]).slice(1, 2);
    },
    sdaytextslice23: function() {
        return String(translate[options.languages].sday[this.day()]).slice(2, 3);
    },
    mdaytext: function() {
        return translate[options.languages].mday[this.day()];
    },
    snextday: function() {
        return (this.day() === 6) ? translate[options.languages].sday[0] : translate[options.languages].sday[this.day() + 1];
    },
    sprevday: function() {
        return (this.day() === 0) ? translate[options.languages].sday[6] : translate[options.languages].sday[this.day() - 1];
    },
    monthtext: function() {
        return translate[options.languages].month[this.month()];
    },
    monthtextcut: function() {
        return translate[options.languages].month[this.month()].substring(3);
    },
    nextmonthtext: function() {
        return (this.month() === 11) ? translate[options.languages].month[0] : translate[options.languages].month[this.month() + 1];
    },
    prevmonthtext: function() {
        return (this.month() === 0) ? translate[options.languages].month[11] : translate[options.languages].month[this.month() - 1];
    },
    smonthtext: function() {
        return translate[options.languages].smonth[this.month()];
    },
    smonthtextslice01: function() {
        return String(translate[options.languages].smonth[this.month()]).slice(0, 1);
    },
    smonthtextslice12: function() {
        return String(translate[options.languages].smonth[this.month()]).slice(1, 2);
    },
    smonthtextslice23: function() {
        return String(translate[options.languages].smonth[this.month()]).slice(2, 3);
    },
    snextmonth: function() {
        return (this.month() === 11) ? translate[options.languages].smonth[0] : translate[options.languages].smonth[this.month() + 1];
    },
    sprevmonth: function() {
        return (this.month() === 0) ? translate[options.languages].smonth[11] : translate[options.languages].smonth[this.month() - 1];
    },
    datetext: function() {
        var textdate = ["First", "Second", "Third", "Fourth", "Fifth", "Sixth", "Seventh", "Eighth", "Ninth", "Tenth", "Eleventh", "Twelfth", "Thirteenth", "Fourteenth", "Fifteenth", "Sixteenth", "Seventeenth", "Eightheenth", "Nineteenth", "Twentieth", "TwentyFirst", "TwentySecond", "TwentyThird", 'TwentyFourth', "TwentyFifth", "TwentySixth", "TwentySeventh", "TwentyEight", "TwentyNinth", "Thirtyith", "ThirtyFirst"];
        return textdate[this.date() - 1];
    },
    nth: function(d) {
        if (d > 3 && d < 21) {
            return 'th';
        }
        switch (d % 10) {
            case 1:
                return "st";
            case 2:
                return "nd";
            case 3:
                return "rd";
            default:
                return "th";
        }
    },
    dateplus: function() {
        return this.date() + this.nth(Number(this.date()));
    },
    getTimer: function() {
        return iOSClockTimer;
    },
    hrmintx: function() {
        return (this.minutetwotext() !== "") ? this.hourtextdot() + '.' + this.minuteonetextdot() + '.' + this.minutetwotext() : this.hourtextdot() + '.' + this.minuteonetextdot() + this.minutetwotext();
    },
    yeartext: function() {
        return convertTOWord(this.year());
    }
};
weatherMethods = {
    spd: function(){
        return (options.celsius === true) ? 'kph' : 'mph';
    },
    celsiusorfareinheight: function(){
        return (options.celsius === true) ? 'c' : 'f';
    },
    cvtF: function(temp) {
        //letting iOS handle this
        //return (temp == "--") ? this.temp() : Math.round(temp * 1.8 + 32);
        return temp;
    },
    cvtK: function(wind) {
        return Math.round(((wind * 1.609344) * 100) / 100);
    },
    cvtM: function(distance) {
        return Math.round(distance * 1.60934);
    },
    cvtS: function(time) {
        var timecut, timeE, cvtt;
        if (String(time).length > 3) {
            timecut = String(time).slice(0, 2);
            timeE = String(time).slice(2, 4);
        } else {
            timeE = String(time).slice(1, 3);
            timecut = String(time).slice(0, 1);
        }
        if (timecut === "00") {
            return 12;
        }
        cvtt = (timecut > 12) ? timecut - 12 : timecut;
        return cvtt + ":" + timeE;
    },
    cvtTwentyFour: function(time) {
        var strTime = String(time),
            secondPart = strTime.slice(-2),
            firstPart = strTime.replace(secondPart, "");
        return firstPart + ":" + secondPart;
    },
    degToCompass: function(num) {
        var val = Math.floor((num / 22.5) + 0.5),
            arr = ["N", "NNE", "NE", "ENE", "E", "ESE", "SE", "SSE", "S", "SSW", "SW", "WSW", "W", "WNW", "NW", "NNW"];
        return arr[(val % 16)];
    },
    temp: function() {
        return (options.celsius ? Math.round(injectedWeather.temperature) : this.cvtF(injectedWeather.temperature));
    },
    high: function(deg) {
        if (!deg) {
            deg = '';
        }
        return (options.celsius ? Math.round(injectedWeather.dayForecasts[0].high) + deg : this.cvtF(injectedWeather.dayForecasts[0].high) + deg);
    },
    low: function(deg) {
        if (!deg) {
            deg = '';
        }
        return (options.celsius ? Math.round(injectedWeather.dayForecasts[0].low) + deg : this.cvtF(injectedWeather.dayForecasts[0].low) + deg);
    },
    condition: function() {
        return translate[options.languages].condition[injectedWeather.conditionCode];
    },
    conditionlowercase: function() {
        var string = String(translate[options.languages].condition[injectedWeather.conditionCode]).toLowerCase();
        if (string === 'fog') {
            string = 'foggy';
        }
        return string;
    },
    icon: function() {
        return injectedWeather.conditionCode;
    },
    iconday1: function() {
        if (injectedWeather.dayForecasts[1].icon) {
            return injectedWeather.dayForecasts[1].icon;
        } else {
            return 20;
        }
    },
    iconday2: function() {
        if (injectedWeather.dayForecasts[2].icon) {
            return injectedWeather.dayForecasts[2].icon;
        } else {
            return 20;
        }
    },
    iconday3: function() {
        if (injectedWeather.dayForecasts[3].icon) {
            return injectedWeather.dayForecasts[3].icon;
        } else {
            return 20;
        }
    },
    iconday4: function() {
        if (injectedWeather.dayForecasts[4].icon) {
            return injectedWeather.dayForecasts[4].icon;
        } else {
            return 20;
        }
    },
    iconday5: function() {
        if (injectedWeather.dayForecasts[5].icon) {
            return injectedWeather.dayForecasts[5].icon;
        } else {
            return 20;
        }
    },
    //dayNumber
    //dayOfWeek
    day1lohigh: function() {
        if (injectedWeather.dayForecasts[1].low) {
            return injectedWeather.dayForecasts[1].high + "&deg;/" + injectedWeather.dayForecasts[1].low + "&deg;";
        } else {
            return "0&deg;/0&deg;";
        }
    },
    day2lohigh: function() {
        if (injectedWeather.dayForecasts[2].low) {
            return injectedWeather.dayForecasts[2].high + "&deg;/" + injectedWeather.dayForecasts[2].low + "&deg;";
        } else {
            return "0&deg;/0&deg;";
        }
    },
    day3lohigh: function() {
        if (injectedWeather.dayForecasts[3].low) {
            return injectedWeather.dayForecasts[3].high + "&deg;/" + injectedWeather.dayForecasts[3].low + "&deg;";
        } else {
            return "0&deg;/0&deg;";
        }
    },
    day4lohigh: function() {
        if (injectedWeather.dayForecasts[4].low) {
            return injectedWeather.dayForecasts[4].high + "&deg;/" + injectedWeather.dayForecasts[4].low + "&deg;";
        } else {
            return "0&deg;/0&deg;";
        }
    },
    day5lohigh: function() {
        if (injectedWeather.dayForecasts[5].low) {
            return injectedWeather.dayForecasts[5].high + "&deg;/" + injectedWeather.dayForecasts[5].low + "&deg;";
        } else {
            return "0&deg;/0&deg;";
        }
    },
    day1day: function() {
        if (injectedWeather.dayForecasts[1].dayOfWeek) {
            return translate[options.languages].sday[injectedWeather.dayForecasts[1].dayOfWeek - 1];
        } else {
            return 'Nil';
        }
    },
    day2day: function() {
        if (injectedWeather.dayForecasts[2].dayOfWeek) {
            return translate[options.languages].sday[injectedWeather.dayForecasts[2].dayOfWeek - 1];
        } else {
            return 'Nil';
        }
    },
    day3day: function() {
        if (injectedWeather.dayForecasts[3].dayOfWeek) {
            return translate[options.languages].sday[injectedWeather.dayForecasts[3].dayOfWeek - 1];
        } else {
            return 'Nil';
        }
    },
    day4day: function() {
        if (injectedWeather.dayForecasts[4].dayOfWeek) {
            return translate[options.languages].sday[injectedWeather.dayForecasts[4].dayOfWeek - 1];
        } else {
            return 'Nil';
        }
    },
    day5day: function() {
        if (injectedWeather.dayForecasts[5].dayOfWeek) {
            return translate[options.languages].sday[injectedWeather.dayForecasts[5].dayOfWeek - 1];
        } else {
            return 'Nil';
        }
    },
    day1high: function() {
        return injectedWeather.dayForecasts[1].high;
    },
    day2high: function() {
        return injectedWeather.dayForecasts[2].high;
    },
    day3high: function() {
        return injectedWeather.dayForecasts[3].high;
    },
    day4high: function() {
        return injectedWeather.dayForecasts[4].high;
    },
    day5high: function() {
        return injectedWeather.dayForecasts[5].high;
    },
    day1low: function() {
        return injectedWeather.dayForecasts[1].low;
    },
    day2low: function() {
        return injectedWeather.dayForecasts[2].low;
    },
    day3low: function() {
        return injectedWeather.dayForecasts[3].low;
    },
    day4low: function() {
        return injectedWeather.dayForecasts[4].low;
    },
    day5low: function() {
        return injectedWeather.dayForecasts[5].low;
    },
    city: function() {
        return injectedWeather.name;
    },
    humidity: function() {
        return Math.round(injectedWeather.humidity);
    },
    windchill: function(deg) {
        if (!deg) {
            deg = '';
        }
        return Math.round(injectedWeather.windChill) + deg;
    },
    wind: function() {
        return (options.celsius ? this.cvtK(Math.round(injectedWeather.windSpeed)) + this.spd() : Math.round(injectedWeather.windSpeed) + this.spd());
    },
    direction: function() {
        return this.degToCompass(injectedWeather.windDirection);
    },
    visible: function() {
        return (options.celsius ? this.cvtM(Math.round(injectedWeather.visibility)) + this.spd() : Math.round(injectedWeather.visibility) + this.spd());
    },
    rain: function() {
        var percent = (injectedWeather.precipitationForecast === 2) ? 0 : injectedWeather.precipitationForecast;
        return percent;
    },
    dewpoint: function() {
        return Math.round(injectedWeather.dewPoint);
    },
    feelslike: function() {
        return (options.celsius ? Math.round(injectedWeather.feelsLike) : this.cvtF(injectedWeather.feelsLike));
    },
    sunset: function() {
        return (options.celsius ? this.cvtTwentyFour(injectedWeather.sunsetTime) : this.cvtS(injectedWeather.sunsetTime));
    },
    sunrise: function() {
        return (options.celsius ? this.cvtTwentyFour(injectedWeather.sunriseTime) : this.cvtS(injectedWeather.sunriseTime));
    },
    updated: function() {
        return injectedWeather.updateTimeString;
    },
    battery: function() {
        return injectedSystem.battery;
    },
    charging: function() {
        return injectedSystem.chargetext;
    },
    charginglowercase: function() {
        return String(injectedSystem.chargetext).toLowerCase();
    }
};
systemMethods = {
    signalArray : ["0%", "20%", "40%", "60%", "80%", "100%"],
    percent : ['0', '40', '60', '100'],
    ipaddress: function(){
        return (injectedSystem.ipaddress == "error") ? "No Wifi" : injectedSystem.ipaddress;
    },
    devicename: function(){
        return injectedSystem.deviceName;
    },
    firmware: function(){
        return injectedSystem.systemVersion;
    },
    battery: function(){
        return injectedSystem.battery;
    },
    chargetext: function(){
        return injectedSystem.chargetext;
    },
    onlycharging: function(){
        return (injectedSystem.chargetext === 'Charging') ? 'Charging' : '';
    },
    signalbars: function(){
        return injectedSystem.signalBars;
    },
    signalpercent: function(){
        return this.signalArray[injectedSystem.signalBars];
    },
    getalarmday: function(){
        if(injectedSystem.alarmDay){
            return translate[options.languages].sday[injectedSystem.alarmDay];
        }else{
            return "";
        }
    },
    getalarmstring: function(){
        if(injectedSystem.alarmString){
            var split = injectedSystem.alarmString.split(':'),
            hr = split[0],
            min = split[1].split(' ')[0],
            am = split[1].split(' ')[1];
            if(min < 10 && min != "00"){
                min = "0" + min;
            }
            return hr + ":" + min + " " + am;
        }else{
            return "";
        }
    },
    getalarmtime: function(){
        if(injectedSystem.alarmTime){
            var split = injectedSystem.alarmTime.split(':'),
            hr = split[0];
            min = split[1];
            if(min < 10 && min != "00"){
                min = "0" + min;
            }
            return hr + ":" + min;
        }else{
            return "";
        }
    },
    getalarmhr: function(){
        if(injectedSystem.alarmHour){
            return injectedSystem.alarmHour;
        }else{
            return "";
        }
    },
    getalarmmin: function(){
        if(injectedSystem.alarmMinute){
            return (injectedSystem.alarmMinute < 10 && injectedSystem.alarmMinute != "00") ? "0" + injectedSystem.alarmMinute : injectedSystem.alarmMinute;
        }else{
            return "";
        }
    },
    getalarmweekday: function(){
        if(injectedSystem.alarmDay){
            return translate[options.languages].weekday[injectedSystem.alarmDay];
        }else{
            return "";
        }
    },
    wifi: function(){
        return this.percent[Number(injectedSystem.wifiBars)];
    },
    mailbadge: function(){
        return injectedSystem.mailBadge;
    },
    smsbadge: function(){
        return injectedSystem.smsBadge;
    },
    phonebadge: function(){
        return injectedSystem.phoneBadge;
    },
    whatsbadge: function(){
        if(injectedSystem.whatsBadge <= 0){
            return 0;
        }
        return injectedSystem.whatsBadge || 0;
    },
    telegrambadge: function(){
        return injectedSystem.telegramBadge || 0;
    },
    fbmessengerbadge: function(){
        if(injectedSystem.fbMessengerBadge <= 0){
            return 0;
        }
        return injectedSystem.fbMessengerBadge || 0;
    },
    discordbadge: function(){
        return injectedSystem.discord || 0;
    },
    viberbadge: function(){
        return injectedSystem.viber || 0;
    },
    instagrambadge: function(){
        return injectedSystem.instagram || 0;
    },
    facebookbadge: function(){
        if(injectedSystem.facebook <= 0){
            return 0;
        }
        return injectedSystem.facebook || 0;
    },
    gmailbadge: function(){
        return injectedSystem.gmail || 0;
    },
    outlookbadge: function(){
        return injectedSystem.outlook || 0;
    },
    airmailbadge: function(){
        return injectedSystem.airmail || 0;
    },
    ymailbadge: function(){
        return injectedSystem.ymail || 0;
    },
    snapchatbadge: function(){
        return injectedSystem.snapchat || 0;
    },
    redditbadge: function(){
        return injectedSystem.reddit || 0;
    },
    googleplusbadge: function(){
        return injectedSystem.googleplus || 0;
    },
    linkedinbadge: function(){
        return injectedSystem.linkedin || 0;
    },
    slackbadge: function(){
        return injectedSystem.slack || 0;
    },
    telegramxbadge: function(){
        return injectedSystem.telegramXBadge || 0;
    },
    sparkbadge: function(){
        return injectedSystem.spark || 0;
    },
    twitterbadge: function(){
        return injectedSystem.twitter || 0;
    },
    tweetbot4badge: function(){
        return injectedSystem.tweetbot4 || 0;
    },
    youtubebadge: function(){
        return injectedSystem.youtube || 0;
    },
    ramFree: function(){
        return injectedSystem.ramFree;
    },
    ramUsed: function(){
        return injectedSystem.ramUsed;
    },
    ramAvailable: function(){
        return injectedSystem.ramAvailable;
    }
};

