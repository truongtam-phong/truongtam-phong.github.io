var MainColor = "White"; 
var HeaderBackground = ""; 
var LightIcons = true; 
var HideLine = true; 