var DayColor = "#ddd"; // Trộn màu cho Ngày
var FooterColor = "#dddddd"; // Màu nội dung văn bản
var Motto = "Nhìn lên các ngôi sao và không nhìn xuống dưới chân của bạn. Cố gắng hiểu ý nghĩa của những gì bạn nhìn thấy và tự hỏi về những gì mà bạn đã làm cho vũ trụ tồn tại."; // Văn bản
var ZoomLevel = 80; // Cỡ Phông
