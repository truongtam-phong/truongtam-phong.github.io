/**/ var savedElements = {"overlay":"","placedElements":{


"zclock":{"text-align":"center","position":"absolute","font-family":"TruongTamPhong","padding-left":"0px","width":"328.6px","font-size":"51px", "font-weight":"bold","color":"white", "position":"absolute","height":"76px","z-index":"2","top":"43px","letter-spacing":"0px"},


"daydatesmonth":{"font-family":"TruongTamPhong","text-align":"center", "padding-left":"0px","width":"328.6px","z-index":"2","color":"white","position":"absolute","font-size":"11px","font-weight":"bold","top":102,"height":"17px"}},"iconName":"iPhone Clock"}